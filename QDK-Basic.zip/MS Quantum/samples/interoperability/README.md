# Interoperating with Q\#

These samples show how to use Q# with different host languages.

- **[Python](./python/)**: This sample demonstrates using Q# from a Python host program.
- **[.NET](./dotnet/)**: This sample demonstrates using Q# from C# and F# host programs.
