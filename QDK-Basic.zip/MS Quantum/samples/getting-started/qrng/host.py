# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

import qsharp
from Qrng import SampleQuantumRandomNumberGenerator

print(SampleQuantumRandomNumberGenerator.simulate())
